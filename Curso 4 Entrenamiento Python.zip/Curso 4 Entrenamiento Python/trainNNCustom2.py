#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jul 19 17:13:25 2025

@author: Neuro Capture
"""

import numpy as np
import matplotlib.pyplot as plt

# =======================
# RED NEURONAL CUSTOM
# Perceptrón Multicapa Arquitectura 3-4-1
# =======================

# Configuración de red
input_size = 3
hidden_size = 4
output_size = 1

# Datos de entrada
X = np.array([
    [25, 85, 1005], [28, 60, 1012], [22, 90, 1003], [30, 50, 1015], [24, 80, 1008],
    [27, 55, 1011], [23, 88, 1002], [29, 58, 1013], [26, 77, 1006], [31, 45, 1016],
    [21, 92, 1001], [28, 59, 1012], [25, 80, 1005], [27, 65, 1009], [32, 40, 1018],
    [24, 87, 1003], [29, 54, 1014], [26, 75, 1007], [30, 52, 1015], [22, 91, 1002]
], dtype=float)

X = (X - np.mean(X, axis=0)) / np.std(X, axis=0)  # Normalizar
Y = np.array([
    1, 0, 1, 0, 1,
    0, 1, 0, 1, 0,
    1, 0, 1, 1, 0,
    1, 0, 1, 0, 1
], dtype=float).reshape(-1, 1)  # 20x1

# Inicialización
np.random.seed(0)
W1 = np.random.randn(hidden_size, input_size)  # 4x3
b1 = np.random.randn(hidden_size, 1)           # 4x1
W2 = np.random.randn(output_size, hidden_size) # 1x4
b2 = np.random.randn(output_size, 1)           # 1x1

# Funciones de activación
def tanh(x):
    return np.tanh(x)

def tanh_deriv(x):
    return 1 - np.tanh(x) ** 2

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_deriv(x):
    s = sigmoid(x)
    return s * (1 - s)

# Hiperparámetros
lr = 0.1
epochs = 10000
N = X.shape[0]

# Para visualizar la pérdida
loss_history = []

# Entrenamiento
for epoch in range(1, epochs + 1):
    total_loss = 0

    for i in range(N):
        # =====================
        # Forward propagation
        # =====================
        x = X[i].reshape(-1, 1)    # 3x1
        y = Y[i]                   # escalar

        z1 = W1 @ x + b1          # 4x1
        a1 = tanh(z1)             # 4x1

        z2 = W2 @ a1 + b2         # 1x1
        a2 = sigmoid(z2)          # 1x1

        # =====================
        # Backpropagation
        # =====================
        error = a2 - y                           # 1x1
        delta2 = error * sigmoid_deriv(z2)       # 1x1

        dW2 = delta2 @ a1.T                      # 1x4
        db2 = delta2                             # 1x1

        delta1 = (W2.T @ delta2) * tanh_deriv(z1)  # 4x1
        dW1 = delta1 @ x.T                       # 4x3
        db1 = delta1                             # 4x1

        # =====================
        # Actualización
        # =====================
        W2 -= lr * dW2
        b2 -= lr * db2

        W1 -= lr * dW1
        b1 -= lr * db1

        # Acumular pérdida
        total_loss += 0.5 * (a2 - y)**2

    # Registrar pérdida
    loss_history.append(total_loss.item() / N)

    # Mostrar pérdida cada 100 épocas
    if epoch % 100 == 0:
        print(f"Epoch {epoch}, Loss = {loss_history[-1]:.8f}")
        
    if epoch % 10000 == 0:
        print("\nPesos y Bias para inferencia: \n")
        print(f"W1 {W1}, \nb1 = {b1}\n")
        print(f"W2 {W2}, \nb2 = {b2}")

# ============================
# Visualización de la curva de pérdida
# ============================
plt.figure(figsize=(8, 4))
plt.plot(loss_history, label="Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.title("Curva de pérdida durante el entrenamiento")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
