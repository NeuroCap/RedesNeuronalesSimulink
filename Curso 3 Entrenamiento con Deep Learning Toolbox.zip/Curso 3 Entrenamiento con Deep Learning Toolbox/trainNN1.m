inputs = [25 28 22 30 24 27 23 29 26 31 21 28 25 27 32 24 29 26 30 22;
          85 60 90 50 80 55 88 58 77 45 92 59 80 65 40 87 54 75 52 91;
          1005 1012 1003 1015 1008 1011 1002 1013 1006 1016 1001 1012 1005 1009 1018 1003 1014 1007 1015 1002];
targets = [1 0 1 0 1 0 1 0 1 0 1 0 1 1 0 1 0 1 0 1];

net = feedforwardnet(4); % 4 neuronas ocultas
net.layers{1}.transferFcn = 'tansig';
net.layers{2}.transferFcn = 'logsig';
net.trainParam.epochs = 1000;
net.trainParam.goal = 1e-3;

[net, tr] = train(net, inputs, targets);

% Para ver modelo en Simulink automático
%gensim(net)

%% Para extraer los pesos y bias
% Capa oculta 
W1 = net.IW{1,1} % Matriz de pesos de la capa 1
b1 = net.b{1} % Vector de bias de la capa 1

% Capa de salida
W2 = net.LW{2,1} % Matriz de pesos de la capa 2
b2 = net.b{2} % Vector de bias de la capa 2

% Para la arquitectura 3-4-1:
% W1 será de tamaño 4×3 (4 neuronas ocultas, 3 entradas)
% b1 será de tamaño 4×1
% W2 será de tamaño 1×4 (1 salida, 4 neuronas ocultas)
% b2 será un escalar (1×1)

% h=tanh(W1⋅x + b1)
%y^ =σ(W2 ⋅h + b2)

