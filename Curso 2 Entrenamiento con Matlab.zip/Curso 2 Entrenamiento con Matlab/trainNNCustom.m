% =======================
% RED NEURONAL CUSTOM
% Perceptrón Multicapa Arquitectura 3-4-1
% =======================

% Configuración de red
inputSize = 3;
hiddenSize = 4;
outputSize = 1;

% Datos de entrada
N = 20; % Número de datos
X = [25 85 1005; 28 60 1012; 22 90 1003; 30 50 1015; 24 80 1008; 27 55 1011; 23 88 1002; 29 58 1013; 26 77 1006;
     31 45 1016; 21 92 1001; 28 59 1012; 25 80 1005; 27 65 1009; 32 40 1018; 24 87 1003; 29 54 1014; 26 75 1007;
     30 52 1015; 22 91 1002];  % 20x3

X = (X - mean(X)) ./ std(X); % Normalizar datos de entrada

Y = [1; 0; 1; 0; 1; 0; 1; 0; 1; 0;
           1; 0; 1; 1; 0; 1; 0; 1; 0; 1];

% Inicialización de pesos y bias
rng(0); % Para reproducibilidad --> Para reproducir los mismos resultados aleatorios cuando se ejecute el código
W1 = randn(hiddenSize, inputSize);   % Pesos iniciales capa oculta (4x3)
b1 = randn(hiddenSize, 1);           % Bias iniciales capa oculta (4x1)

W2 = randn(outputSize, hiddenSize);  % Pesos iniciales capa salida (1x4)
b2 = randn(outputSize, 1);            % Bias iniciales capa salida (1x1)

% Funciones de activación y sus derivadas
tanhAct = @(x) tanh(x);
tanhDeriv = @(x) 1 - tanh(x).^2;

sigmoid = @(x) 1 ./ (1 + exp(-x));
sigmoidDeriv = @(x) sigmoid(x) .* (1 - sigmoid(x));

% Hiperparámetros
lr = 0.1;
epochs = 10000;

% Entrenamiento
for epoch = 1:epochs
    totalLoss = 0; % Se inicializa la función de pérdida.
    
    for i = 1:N
        % =====================
        % Forward propagation
        % =====================
        x = X(i,:)';   % 3x1 -> Entrada dato a dato
        y = Y(i);      % Escalar -> Salida correcta 

        z1 = W1 * x + b1;           % 4x1  
        a1 = tanhAct(z1);          % 4x1

        z2 = W2 * a1 + b2;          % 1x1
        a2 = sigmoid(z2);           % Salida predicha (1x1)

        % =====================
        % Backpropagation
        % =====================
        error = a2 - y;                          % Error de salida
        delta2 = error .* sigmoidDeriv(z2);     % Delta de salida (1x1)

        dW2 = delta2 * a1';                      % 1x4
        db2 = delta2;                            % 1x1

        delta1 = (W2' * delta2) .* tanhDeriv(z1);   % 4x1
        dW1 = delta1 * x';                       % 4x3
        db1 = delta1;                            % 4x1

        % =====================
        % Actualización de pesos y bias
        % =====================
        W2 = W2 - lr * dW2;
        b2 = b2 - lr * db2;

        W1 = W1 - lr * dW1;
        b1 = b1 - lr * db1;

        % Acumular pérdida
        totalLoss = totalLoss + 0.5 * (a2 - y)^2;
    end

    % Mostrar error cada 100 épocas
    if mod(epoch, 100) == 0
        fprintf('Epoch %d, Loss = %.8f\n', epoch, totalLoss / N);
    end
end



% =====================
% Evaluación
% =====================
%Y_pred = zeros(N,1);

Y_pred = Y;

for i = 1:N
    x = X(i,:)';
    z1 = W1 * x + b1;
    a1 = tanhAct(z1);
    z2 = W2 * a1 + b2;
    a2 = sigmoid(z2);
    Y_pred(i) = a2 > 0.5;  % binarizar
end

accuracy = sum(Y_pred == Y) / N;
fprintf('Precisión final: %.2f %%\n', accuracy * 100);


%{
x = X(2,:)';
z1 = W1 * x + b1;
a1 = tanhAct(z1);
z2 = W2 * a1 + b2;
a2 = sigmoid(z2);
Y_pred(1) = a2 > 0.5;  % binarizar
%}
